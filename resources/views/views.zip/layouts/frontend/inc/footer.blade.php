<footer class="page_footer template_footer ds ms parallax overlay_color section_padding_top_110 section_padding_bottom_100 columns_padding_25">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12 col-md-push-6 text-center">
                <div class="widget widget_text widget_about">
                    <div class="logo logo_with_text bottommargin_10"> <img src="{{ asset('frontend/images/logo.png') }}" alt=""> <span class="logo_text">
                            E MEDICINE
                            <small class="highlight4">Served 24 Hours to Yor Door</small>
                        </span> </div>
                    <p class="topmargin_25"> <a class="fa fa-facebook" href="#" title="Facebook"></a> <a class="fa fa-twitter" href="#" title="Twitter"></a> <a class="fa fa-google" href="#" title="Google Plus"></a> <a class="fa fa-linkedin" href="#" title="Linkedin"></a> <a class="fa fa-youtube" href="#" title="Youtube"></a> </p>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12 col-md-pull-6 text-center">
                <div class="widget widget_text">
                    <h3 class="widget-title">Our Contacts</h3>
                    <ul class="list-unstyled greylinks">
                        <li class="media"> <i class="fa fa-map-marker highlight rightpadding_5" aria-hidden="true"></i> 74/A Green Rd, Dhaka 1205, Bangladesh </li>
                        <li class="media"> <i class="fa fa-phone highlight rightpadding_5" aria-hidden="true"></i> +88019 69474545 (operator) </li>
                        <li class="media"> <i class="fa fa-pencil highlight rightpadding_5" aria-hidden="true"></i> <a href="mailto:diversify@example.com">akjamil2009@gmail.com</a> </li>
                        <li class="media"> <i class="fa fa-clock-o highlight rightpadding_5" aria-hidden="true"></i> Mon-Fri: 9:00-19:00, Sat: 10:00-17:00 </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<section class="ds ms parallax page_copyright overlay_color section_padding_top_30 section_padding_bottom_30">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <p>&copy; Copyright 2018. All Rights Reserved.</p>
            </div>
        </div>
    </div>
</section>
</div>
<!-- eof #box_wrapper -->
</div>
